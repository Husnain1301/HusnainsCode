package com.example.hopebin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.ui.SignInUI;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.mobile.auth.core.IdentityManager;

public class MainPage extends AppCompatActivity {

    String Account_Username;
    DynamoDBMapper dynamoDBMapper;
    Button MapsBtn;
    TextView UserWelcomeMessageMA;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        AndroidUI();
        ReadUserData();
        MapsBtn = findViewById(R.id.MapsBtn);


        MapsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainPage.this, GoogleMaps.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.themenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.LogOutMenu: {
                LogOut();
            }
        }
        return super.onOptionsItemSelected(item);
    }
    public void LogOut(){
        Toast.makeText(MainPage.this, "Sign out successful", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(MainPage.this, AuthenticatorActivity.class));
        IdentityManager.getDefaultIdentityManager().signOut();
    }
    public void AndroidUI(){
        UserWelcomeMessageMA = findViewById(R.id.UserWelcomeMessageMA);
    }

    public void ReadUserData(){
        new Thread(new Runnable() {
            @Override
            // Here i am trying to retrieve data to display in the WelcomeMessageMA (TextView). I am trying to display the the users First name. I have been using
            // the following link as a form of guidance however this has not helped me with my problem. Link:
            // https://github.com/awsdocs/aws-mobile-developer-guide/blob/master/doc_source/how-to-nosql-integrate-an-existing-table.rst#read-load-an-item

            public void run() { com.amazonaws.models.nosql.CustomerInformationDO UserInfo = dynamoDBMapper.load(com.amazonaws.models.nosql.CustomerInformationDO.class, "userId" // Partition key
                    , "Account Username"); // Sort Key

                    UserWelcomeMessageMA.setText(String.format("" + UserInfo.toString()));
            }
        }).start();
    }

}
