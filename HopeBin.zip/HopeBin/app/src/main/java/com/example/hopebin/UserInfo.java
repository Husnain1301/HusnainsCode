package com.example.hopebin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialogFragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.service.autofill.UserData;
import android.text.method.SingleLineTransformationMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.ui.SignInUI;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;

public class UserInfo extends AppCompatActivity {

    private DynamoDBMapper dynamoDBMapper;
    private EditText AccountUsernameUI, AgeUI, FirstNameUI, LastNameUI, PreferredNameUI;
    private TextView UserIdUI;
    private Button SaveButtonUI;
    String Account_Username_UI;
    String Age_UI;
    String First_Name_UI;
    String Last_Name_UI;
    String Preferred_Name_UI;
    String User_Id_UI;
    private String UserCognitoID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        AndroidUI();
        DialogMessageExtension();
        new CognitoID().execute();

        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {
            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(AWSMobileClient.getInstance().getCredentialsProvider());
                dynamoDBMapper = DynamoDBMapper.builder().dynamoDBClient(dynamoDBClient).awsConfiguration(AWSMobileClient.getInstance().getConfiguration()).build();
            }
        }).execute();

        SaveButtonUI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (FieldValidator() == true) {
                    CreateUserInfoData();
                    Toast.makeText(UserInfo.this, "Data save successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(UserInfo.this, MainPage.class));
                } else {
                    Toast.makeText(UserInfo.this, "Data save unsuccessful. Please Check to see if you have filled in all fields correctly", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.themenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.LogOutMenu: {
                LogOut();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    public void CreateUserInfoData() {
        final com.amazonaws.models.nosql.CustomerInformationDO UserInfoData = new com.amazonaws.models.nosql.CustomerInformationDO();
        User_Id_UI = UserIdUI.getText().toString();
        Account_Username_UI = AccountUsernameUI.getText().toString().trim();
        Age_UI = AgeUI.getText().toString().trim();
        First_Name_UI = FirstNameUI.getText().toString().trim();
        Last_Name_UI = LastNameUI.getText().toString().trim();
        Preferred_Name_UI = PreferredNameUI.getText().toString().trim();

        UserInfoData.setUserId(User_Id_UI);
        UserInfoData.setAccountUsername(Account_Username_UI);
        UserInfoData.setAge(Age_UI);
        UserInfoData.setFirstName(First_Name_UI);
        UserInfoData.setLastName(Last_Name_UI);
        UserInfoData.setPreferredName(Preferred_Name_UI);

        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(UserInfoData);
            }
        }).start();
    }

    public void LogOut() {
        Toast.makeText(UserInfo.this, "Sign out successful", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(UserInfo.this, AuthenticatorActivity.class));
        IdentityManager.getDefaultIdentityManager().signOut();
    }

    public void AndroidUI() {
        AccountUsernameUI = findViewById(R.id.AccountUsernameUI);
        AgeUI = findViewById(R.id.AgeUI);
        FirstNameUI = findViewById(R.id.FirstnameUI);
        LastNameUI = findViewById(R.id.LastnameUI);
        PreferredNameUI = findViewById(R.id.PreferredNameUI);
        SaveButtonUI = findViewById(R.id.SaveBtnUI);
        UserIdUI = findViewById(R.id.UserIdUI);
    }

    public boolean FieldValidator() {
        Account_Username_UI = AccountUsernameUI.getText().toString().trim();
        Age_UI = AgeUI.getText().toString().trim();
        First_Name_UI = FirstNameUI.getText().toString().trim();
        Last_Name_UI = LastNameUI.getText().toString().trim();
        Preferred_Name_UI = PreferredNameUI.getText().toString().trim();
        boolean FieldValidatorPassed;
        if (Account_Username_UI.isEmpty() || Age_UI.isEmpty() || First_Name_UI.isEmpty() || Last_Name_UI.isEmpty() || Preferred_Name_UI.isEmpty()) {
            FieldValidatorPassed = false;
            Toast.makeText(UserInfo.this, "Please fill in all fields to continue", Toast.LENGTH_SHORT).show();
        } else {
            FieldValidatorPassed = true;
        }
        return FieldValidatorPassed;
    }

    public static class DialogMessage extends AppCompatDialogFragment {

        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext()).setTitle("Attention").setMessage("Are you new to Hope Bin?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getContext(), MainPage.class));
                    }
                });
        return builder.create();
    }
}
public void DialogMessageExtension(){
        DialogMessage dialogMessage = new DialogMessage();
        dialogMessage.show(getSupportFragmentManager(), "Alert Message");
    }
    public class CognitoID extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... strings) {
            try {
                CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                        getApplicationContext(),
                        "eu-west-2:a9b1ba1b-181d-4ff7-8194-94661e1e84c0", // Identity pool ID
                        Regions.EU_WEST_2);
                UserCognitoID = credentialsProvider.getIdentityId();
            }catch (Exception e){
                System.out.println(e);
            }
            return UserCognitoID;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            UserIdUI.setText("ID: " + UserCognitoID);
        }
    }
}