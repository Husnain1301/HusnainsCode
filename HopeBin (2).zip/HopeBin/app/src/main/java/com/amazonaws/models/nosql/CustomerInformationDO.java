package com.amazonaws.models.nosql;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "hopebin-mobilehub-995211844-CustomerInformation")

public class CustomerInformationDO {
    private String _userId;
    private String _accountUsername;
    private String _age;
    private String _firstName;
    private String _lastName;
    private String _preferredName;

    @DynamoDBHashKey(attributeName = "UserId")
    @DynamoDBAttribute(attributeName = "UserId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBRangeKey(attributeName = "Account Username")
    @DynamoDBAttribute(attributeName = "Account Username")
    public String getAccountUsername() {
        return _accountUsername;
    }

    public void setAccountUsername(final String _accountUsername) {
        this._accountUsername = _accountUsername;
    }
    @DynamoDBAttribute(attributeName = "Age")
    public String getAge() {
        return _age;
    }

    public void setAge(final String _age) {
        this._age = _age;
    }
    @DynamoDBAttribute(attributeName = "First Name")
    public String getFirstName() {
        return _firstName;
    }

    public void setFirstName(final String _firstName) {
        this._firstName = _firstName;
    }
    @DynamoDBAttribute(attributeName = "Last Name")
    public String getLastName() {
        return _lastName;
    }

    public void setLastName(final String _lastName) {
        this._lastName = _lastName;
    }
    @DynamoDBAttribute(attributeName = "Preferred Name")
    public String getPreferredName() {
        return _preferredName;
    }

    public void setPreferredName(final String _preferredName) {
        this._preferredName = _preferredName;
    }

}
