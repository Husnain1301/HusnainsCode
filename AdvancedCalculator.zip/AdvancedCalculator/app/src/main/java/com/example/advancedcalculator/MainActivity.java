package com.example.advancedcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button ZeroBtn;
    Button DotBtn;
    Button EqualsBtn;
    Button OneBtn;
    Button TwoBtn;
    Button ThreeBtn;
    Button PlusBtn;
    Button FourBtn;
    Button FiveBtn;
    Button SixBtn;
    Button MinusBtn;
    Button SevenBtn;
    Button EightBtn;
    Button NineBtn;
    Button MultiplyBtn;
    Button DivideBtn;
    Button Clear;
    TextView Result;
    boolean Add;
    boolean Minus;
    boolean Multiply;
    boolean Divide;
    Double Num1;
    Double Num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ZeroBtn = findViewById(R.id.ZeroBtn);
        DotBtn = findViewById(R.id.DotBtn);
        EqualsBtn = findViewById(R.id.EqualsBtn);
        OneBtn = findViewById(R.id.OneBtn);
        TwoBtn = findViewById(R.id.TwoBtn);
        ThreeBtn = findViewById(R.id.ThreeBtn);
        PlusBtn = findViewById(R.id.PlusBtn);
        FourBtn = findViewById(R.id.FourBtn);
        FiveBtn = findViewById(R.id.FiveBtn);
        SixBtn = findViewById(R.id.SixBtn);
        MinusBtn = findViewById(R.id.MinusBtn);
        SevenBtn = findViewById(R.id.SevenBtn);
        EightBtn = findViewById(R.id.EightBtn);
        NineBtn = findViewById(R.id.NineBtn);
        MultiplyBtn = findViewById(R.id.MultiplyBtn);
        DivideBtn = findViewById(R.id.DivideBtn);
        Clear = findViewById(R.id.ClearBtn);
        Result = findViewById(R.id.ResultsTxtView);


        ZeroBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"0");
            }
        });
        DotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+".");
            }
        });
        OneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"1");
            }
        });
        TwoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"2");
            }
        });
        ThreeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"3");
            }
        });
        FourBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"4");
            }
        });
        FiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"5");
            }
        });
        SixBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"6");
            }
        });
        SevenBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"7");
            }
        });
        EightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"8");
            }
        });
        NineBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText(Result.getText()+"9");
            }
        });
        PlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Num1 = Double.parseDouble(Result.getText()+"");
                Add = true;
                Result.setText(null);
            }
        });
        MinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Num1 = Double.parseDouble(Result.getText()+"");
                Minus = true;
                Result.setText(null);
            }
        });
        MultiplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Num1 = Double.parseDouble(Result.getText()+"");
                Minus = true;
                Result.setText(null);
            }
        });
        DivideBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Num1 = Double.parseDouble(Result.getText()+"");
                Divide = true;
                Result.setText(null);
            }
        });
        EqualsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Num2 = Double.parseDouble(Result.getText()+"");
                if (Add == true)
                {
                    Result.setText(Num1 + Num2 + "");
                    Add = false;
                }
                if (Minus == true)
                {
                    Result.setText(Num1 - Num2 + "");
                    Add = false;
                }
                if (Multiply == true)
                {
                    Result.setText(Num1 * Num2 + "");
                    Add = false;
                }
                if (Divide == true)
                {
                    Result.setText(Num1 / Num2 + "");
                    Add = false;
                }
            }
        });
        Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Result.setText("");
            }
        });
    }
}
