package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText UserInput1;
    EditText UserInput2;
    TextView Answer;
    Button Clear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

        public void Clear (View v) {

        Clear = findViewById(R.id.Clear);
        Answer.setText("");
        UserInput1.setText("");
        UserInput2.setText("");
        }

        public void sumBtn (View v){
            UserInput1 = findViewById(R.id.userInput1);
            UserInput2 = findViewById(R.id.userInput2);
            Answer = findViewById(R.id.Answer);
            int Number1 = Integer.parseInt(UserInput1.getText().toString());
            int Number2 = Integer.parseInt(UserInput2.getText().toString());
            int Result = Number1 + Number2;
            Answer.setText(Integer.toString(Result));

        }
        public void subtract (View v){
            UserInput1 = findViewById(R.id.userInput1);
            UserInput2 = findViewById(R.id.userInput2);
            Answer = findViewById(R.id.Answer);
            int Number1 = Integer.parseInt(UserInput1.getText().toString());
            int Number2 = Integer.parseInt(UserInput2.getText().toString());
            int Result = Number1 - Number2;
            Answer.setText(Integer.toString(Result));
        }
        public void multiply (View v){
            UserInput1 = findViewById(R.id.userInput1);
            UserInput2 = findViewById(R.id.userInput2);
            Answer = findViewById(R.id.Answer);
            int Number1 = Integer.parseInt(UserInput1.getText().toString());
            int Number2 = Integer.parseInt(UserInput2.getText().toString());
            int Result = Number1 * Number2;
            Answer.setText(Integer.toString(Result));
        }
        public void divide (View v){
            UserInput1 = findViewById(R.id.userInput1);
            UserInput2 = findViewById(R.id.userInput2);
            Answer = findViewById(R.id.Answer);
            int Number1 = Integer.parseInt(UserInput1.getText().toString());
            int Number2 = Integer.parseInt(UserInput2.getText().toString());
            int Result = Number1 / Number2;
            Answer.setText(Integer.toString(Result));
        }
}
